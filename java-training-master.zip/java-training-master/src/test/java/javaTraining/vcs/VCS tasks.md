### VCS task
* Create new repo in GitHub under your account
* Clone created repo to your machine
* add newly created README.md file to tracking
* commit README.md
* push commit(s) to remote repo
* create a new branch
* change something in README.md and commit changes to the newly created branch
* push branch to remote repo
* create a PR from GiHub and assign it to your mentor

### Takeaways

