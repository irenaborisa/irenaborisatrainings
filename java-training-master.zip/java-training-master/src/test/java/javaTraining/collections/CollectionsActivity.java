package javaTraining.collections;


public class CollectionsActivity {
    public static void main(String[] args) {
        // TODO #1: initialize a collection

        // END TODO #1

        // TODO #2: add some objects to collection

        // END TODO #2

        // TODO #3: remove added object from collection

        // END TODO #3
    }
}
