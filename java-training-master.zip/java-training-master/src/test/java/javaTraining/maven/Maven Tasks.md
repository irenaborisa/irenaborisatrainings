### Maven Task
* create a a project from a quickstart java archetype
* add latest  version of JUnit asa a dependency 
* create dummy tests
* run tests using maven command
* package your project into executable jar

### Takeaways
* Build management tool based on Project Object Model (POM)
* Dependency management and artifact deployment to Nexus
* Aimed for Java projects but also used in place of sbt (slow build tool)