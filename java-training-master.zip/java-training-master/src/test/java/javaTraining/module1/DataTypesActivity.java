package javaTraining.module1;

public class DataTypesActivity {


	public static void main(String[] args) {

		/* TODO #1: Declare and initialize following primitive variables with some values

		byte
		short
		int
		longk
		float
		double
		char
		boolean
		*/

		// END TODO #1


		// TODO #2: initialize previously declared variables with some values

		// END TODO #2
	}

}
