package javaTraining.module1;

public class ArrayDeclarationActivity {

	public static void main(String[] args) {

		// TODO #1: Declare array of integers and Strings (without initializiation)

		// END TODO #1

		// TODO #2: Initialize/assign previously declared arrays with size of 10

		// END TODO #2


		// TODO #3: assign any String for 1st array element

		// END TODO #3

		// TODO #4: declare, initiliaze and assign 5 elements to an array in another way in one line (with curly braces)
		// both - String and integer arrays

		// END TODO #4


		// TODO #5: access 3rd element from integer array and output it

		// END TODO #5


		// TODO #6: access 1st element from String array

		// END TODO #6
	}
}
