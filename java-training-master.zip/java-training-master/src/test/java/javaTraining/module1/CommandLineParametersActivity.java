
package javaTraining.module1;


public class CommandLineParametersActivity {

	public static void main(String[] args) {
		//	TODO - output first parameter from comand line
	}
}
