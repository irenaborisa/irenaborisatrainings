package javaTraining.module1;

public class VariableActivity {

	/* TODO #1 Declare :
		1. Instance variables with primitive and object variables
		2. Class variables with primitive and object variables
		3. Local variables with primitive and object variables
	*/

	// END TODO #1


	// TODO #2: initialize previously declared instance variable with some value in one method and output it in other method
	// Is it possible to have access to local variable from multiple methods?

	// END TODO #2
}
