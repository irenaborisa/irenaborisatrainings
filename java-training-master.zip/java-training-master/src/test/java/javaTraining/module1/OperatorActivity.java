package javaTraining.module1;

public class OperatorActivity {

    public static void main(String[] args) {

        int x = 1;
        int y = 2;
        int z;

        //TODO - assign the sum of x and y to z variable

        //TODO - write z=z+1 in a shorter way (2 ways possible)

        //TODO - Increment x by 1 and the assign it to z

        //TODO - Assign x variable to z variable and the increment x by 1. NOTE - should be done as one expression

        //TODO - show example of RELATIONAL operator

        //TODO - show example of LOGICAL operator

        //TODO - show example of ()? ():() operator
    }
}
