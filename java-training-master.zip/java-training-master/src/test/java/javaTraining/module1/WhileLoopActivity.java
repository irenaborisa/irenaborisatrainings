package javaTraining.module1;

public class WhileLoopActivity {
	
	public static void main(String[] args) {

		// TODO #1: print numbers from 1 to 10 by using WHILE loop

		// END TODO #1
	}
}
