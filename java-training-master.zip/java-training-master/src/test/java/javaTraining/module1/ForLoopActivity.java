package javaTraining.module1;

public class ForLoopActivity {
	
	public static void main(String[] args) {

		// TODO #1: print numbers from 1 to 10 by using FOR loop

		// END TODO #1


		/* TODO #2: Print 5 by 10 grid. It should look like something like this in the console:
				* * * * * * * * * *
				* * * * * * * * * *
				* * * * * * * * * *
				* * * * * * * * * *
				* * * * * * * * * *
		     Hint - use nested FOR loop
		     */

		// END TODO #2
	}
}
