package javaTraining.module1;

public class CastingActivity {

    public static void main(String arg[]) {

		/* TODO #1: Declare and initialize following primitive variables with some values
		byte
		short
		int
		double
		*/

        // END TODO #1


        // TODO #2: Write a code which will show example of Implicit Casting for previously declared variables

        // END TODO #2


        // TODO #2: Write a code which will show example of Explicit Casting for previously declared variables

        // END TODO #2
    }
}
